/*************************************************

*  Author:           Cavin Mashilangwako
*  Date:             2024-06-11
*  Filename:         create_cti.sql
*  Description:
*  Creates the cti database and members
**************************************************/
-- Tygervalley Pet Shelter (TPS) Database Project
-- User Documentation
-- Purpose
-- The purpose of this project is to design and implement a database system for the Tygervalley Pet Shelter (TPS). This system is intended to manage information about food suppliers, types of food, animal categories, and pet types. The database will also facilitate tracking of food allocations to different animal categories and maintaining stock levels for each pet type.

-- Description
-- The TPS database project includes the following components:

-- **Database Design:**
   -- Creation of tables to store information about manufacturers, food types, animal categories, pet types, and food allocations.
   -- Use of constraints such as `CHECK` and other validation constraints to ensure data integrity.

-- **Views:**
   -- `vw_ManufacturerDetails`: Displays details of manufacturing companies, the food type they supply, food ID, and the amount allocated per category.
   -- `vw_PetsPerType`: Displays each animal type, total animals in stock, the animal category ID, and category name.
   -- `vw_ExpiredFoodDetails`: Displays details of expired food products in use, including company name, contact number, food ID, name, expiry date, amount per category, measurement, and category name.
   -- `vw_LowestFoods`: Displays the category name and the sum of total animals in the category, showing only the three categories with the lowest number of pets.

-- **Stored Procedures:**
   -- `sp_NewPetType`: Inserts a new pet type record, ensuring the foreign key argument is an existing category primary key.
   -- `sp_UpdateStock`: Updates an existing pet type record to add or subtract stock levels.
   -- `sp_DeleteFoodType`: Deletes a specified food type and all dependent records if it exists in the `vw_ExpiredFoodDetails` view.
   -- `sp_Report`: Generates a report for a specified manufacturing company’s details and all its expired products in use.

-- **Triggers:**
   -- `after_insert_pettype`: Triggered after a new pet type is inserted, logging the insertion into an audit table.
   -- `after_update_stocklevel`: Triggered after the stock level of a pet type is updated, logging the update into an audit table.

-- **Indexes:**
   -- Creation of indexes on relevant columns to improve query performance.

-- Database Tables
-- Table: Manufacture
-- Table: FoodTypes
-- Table: AnimalCategories
-- Table: PetTypes
-- Table: FoodAllocations
-- Table: AuditLog


/*************************************************
References:
-- books:
Du Bois, P. 2013. MySQL. Fifth Edition. Pearson Education.
Silberschatz, A., Korth, H.F. and Sudarshan, S., Database System Concepts, 6th edn, McGraw-Hill, New York, 2010.
-- Online:
Oracle Corporation, MySQL 8.0 Reference Manual, 2023, https://dev.mysql.com/doc/refman/8.0/en/, (accessed 12 June 2024).
W3Schools, SQL Tutorial, 2023, https://www.w3schools.com/sql/, (accessed 12 June 2024).
Stack Overflow, Stack Overflow, 2023, https://stackoverflow.com/, (accessed 12 June 2024).
SQLZoo, SQLZoo, 2023, https://sqlzoo.net/, (accessed 12 June 2024).
-- School:
MYLMS
************************************************/