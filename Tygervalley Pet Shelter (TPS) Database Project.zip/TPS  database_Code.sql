/******************************************************************************************************

*  Author:           Cavin Mashilangwako
*  Date:             2024-06-11
*  Filename:         tps_database
*  Decription:        The databasedesign will 
					  store information on their suppliers, food types, animal categories and pet types.     
*  Creates the tps_database and members
**********************************************************************************************************/
# Dropping and recreating the database

DROP DATABASE IF EXISTS tps_database;
CREATE DATABASE tps_database COLLATE latin1_general_ci;

SHOW CREATE DATABASE tps_database;

-- Table to store information about suppliers
CREATE TABLE Manufacture (
    ManufactureID INT AUTO_INCREMENT PRIMARY KEY,
    CompanyName VARCHAR(255) NOT NULL,
    ContactNumber VARCHAR(20),
    Email VARCHAR(255));

-- Table to store information about food types
CREATE TABLE FoodTypes (
    FoodTypeID INT AUTO_INCREMENT PRIMARY KEY,
    FoodName VARCHAR(255) NOT NULL,
    ExpiryDate DATE);


-- Table to store information about animal categories
CREATE TABLE AnimalCategories (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(255) NOT NULL);

-- Table to store information about pet types within categories
CREATE TABLE PetTypes (
    PetTypeID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryID INT,
    PetTypeName VARCHAR(255) NOT NULL,
    StockLevel INT,
    FOREIGN KEY (CategoryID) REFERENCES AnimalCategories (CategoryID));

-- Table to store allocation of food types to animal categories
CREATE TABLE FoodAllocations (
    AllocationID INT AUTO_INCREMENT PRIMARY KEY,
    FoodTypeID INT,
    CategoryID INT,
    QuantityAmount DECIMAL(10, 2),
    QuantityUnit VARCHAR(10),
FOREIGN KEY (FoodTypeID) REFERENCES FoodTypes(FoodTypeID),
FOREIGN KEY (CategoryID) REFERENCES AnimalCategories(CategoryID));

-- Table to store the relationship between suppliers and food types
CREATE TABLE ManufactureFood(
    ManufactureID INT,
    FoodTypeID INT,
    PRIMARY KEY (SupplierID, FoodTypeID),
    FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
    FOREIGN KEY (FoodTypeID) REFERENCES FoodTypes(FoodTypeID));
	
   
    
    
   -- Insert sample data into Suppliers table
INSERT INTO Manufacture (CompanyName, ContactNumber, Email)
VALUES 
('Veggie Land', '123-456-7890', 'contact@veggieland.com'),
('Premier Seed Suppliers', '234-567-8901', 'info@premierseeds.com'),
('Carnivore Foods', '345-678-9012', 'support@carnivorefoods.com'),
('Fish Delight', '456-789-0123', 'sales@fishdelight.com'),
('Pet Nutri', '567-890-1234', 'service@petnutri.com');

-- Insert sample data into FoodTypes table
INSERT INTO FoodTypes (FoodName, ExpiryDate)
VALUES 
('Vegetables', '2024-12-31'),
('Seeds', '2024-11-30'),
('Roast Chicken Pellets', '2024-10-15'),
('Fish Flakes', '2024-09-20'),
('Mixed Nuts', '2024-08-25');

-- Insert sample data into AnimalCategories table
INSERT INTO AnimalCategories (CategoryName)
VALUES 
('Mammals'),
('Birds'),
('Fish'),
('Reptiles'),
('Amphibians');

-- Insert sample data into PetTypes table
INSERT INTO PetTypes (CategoryID, PetTypeName, StockLevel)
VALUES 
(1, 'Dog', 10),
(1, 'Cat', 20),
(2, 'Parrot', 40),
(3, 'Goldfish', 50),
(4, 'Iguana', 5);

-- Insert sample data into FoodAllocations table
INSERT INTO FoodAllocations (FoodTypeID, CategoryID, QuantityAmount, QuantityUnit)
VALUES 
(1, 1, 8.5, 'kg'),
(1, 2, 4.2, 'kg'),
(2, 2, 3.0, 'kg'),
(3, 1, 5.5, 'kg'),
(4, 3, 2.0, 'kg');

-- Insert sample data into ManufactureFood table
INSERT INTO ManufactureFood (ManufacturerID, FoodTypeID)
VALUES 
(1, 1),  -- Veggie Land supplies Vegetables
(2, 2),  -- Premier Seed Suppliers supplies Seeds
(3, 3),  -- Carnivore Foods supplies Roast Chicken Pellets
(4, 4),  -- Fish Delight supplies Fish Flakes
(5, 5);  -- Pet Nutri supplies Mixed Nuts



 CREATE VIEW vw_ManufacturerDetails AS
SELECT
	m.ManufactureID,
    m.CompanyName,
    m.ContactNumber,
    Email,
    F.FoodTypeID,
    FoodName,
    QuantityAmount,
    QuantityUnit,
    CategoryName
FROM 
    Manufacture m
INNER JOIN 
    FoodTypes F ON m.ManufactureID = ManufactureID
INNER JOIN 
    FoodAllocations Fa ON F.FoodTypeID = Fa.FoodTypeID
INNER JOIN 
    AnimalCategories ac ON Fa.CategoryID = Ac.CategoryID;


CREATE VIEW vw_PetsPerType AS
SELECT 
    pt.PetTypeName,
    pt.StockLevel,
    pt.CategoryID,
    ac.CategoryName
FROM 
    PetTypes pt
INNER JOIN 
    AnimalCategories ac ON pt.CategoryID = ac.CategoryID;

CREATE VIEW vw_ExpiredFoodDetails AS
SELECT 
    m.CompanyName,
    m.ContactNumber,
    f.FoodTypeID,
    f.FoodName,
    f.ExpiryDate,
    fa.QuantityAmount,
    fa.QuantityUnit,
    ac.CategoryName,
    CASE
        WHEN  f.ExpiryDate < CURRENT_DATE THEN 'Expired'
        WHEN  f.ExpiryDate = CURRENT_DATE THEN 'Expires Today'
        ELSE 'Not Expired'
    END AS expiry_status
    
FROM 
    Manufacture m
JOIN 
    FoodTypes f ON m.ManufactureID = ManufactureID
JOIN 
    FoodAllocations fa ON f.FoodTypeID = fa.FoodTypeID
JOIN 
    AnimalCategories ac ON fa.CategoryID = ac.CategoryID
WHERE 
    f.ExpiryDate < CURDATE();
    
    
    -- Create vw_LowestFoods View
CREATE VIEW vw_LowestFoods AS
SELECT 
    ac.CategoryName,
    SUM(pt.StockLevel) AS TotalAnimals
FROM 
    AnimalCategories ac
JOIN 
    PetTypes pt ON ac.CategoryID = pt.CategoryID
GROUP BY 
    ac.CategoryName
ORDER BY 
    TotalAnimals ASC
LIMIT 5;


-- Creating procedures
DELIMITER //

CREATE PROCEDURE sp_NewPetType (
    IN PetTypeName VARCHAR(50), 
    IN StockLevel INT, 
    IN CategoryID INT
)
BEGIN
    -- Check if the CategoryID exists
    IF EXISTS (SELECT 1 FROM AnimalCategories WHERE CategoryID = CategoryID) THEN
        -- Insert new pet type record
        INSERT INTO PetTypes (PetTypeName, StockLevel, CategoryID)
        VALUES (PetTypeName, StockLevel, CategoryID);
    ELSE
        -- Signal an error or handle the case where the category does not exist
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CategoryID does not exist.';
    END IF;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE sp_UpdateStock (
    IN PetTypeID INT, 
    IN Quantity INT, 
    IN IsAddition BIT
)
BEGIN
    DECLARE CurrentStock INT;
    
    -- Get current stock level
    SELECT StockLevel INTO CurrentStock FROM PetTypes WHERE PetTypeID = PetTypeID;
    
    -- Update stock level based on IsAddition flag
    IF IsAddition = 1 THEN
        UPDATE PetTypes SET StockLevel = CurrentStock + Quantity WHERE PetTypeID = PetTypeID;
    ELSE
        UPDATE PetTypes SET StockLevel = CurrentStock - Quantity WHERE PetTypeID = PetTypeID;
    END IF;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE sp_DeleteFoodType (
    IN FoodTypeID INT
)
BEGIN
    -- Check if the food type is in the vw_ExpiredFoodDetails view
    IF EXISTS (SELECT 1 FROM vw_ExpiredFoodDetails WHERE FoodTypeID = FoodTypeID) THEN
        -- Delete dependent records first
        DELETE FROM FoodAllocations WHERE FoodTypeID = FoodTypeID;
        
        -- Delete the food type record
        DELETE FROM FoodTypes WHERE FoodTypeID = FoodTypeID;
    ELSE
        -- Signal an error or handle the case where the food type is not in the expired view
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'FoodTypeID not found in expired food details.';
    END IF;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE sp_Report (
    IN ManufactureID INT
)
BEGIN
    DECLARE CompanyName VARCHAR(100);
    DECLARE ContactNumber VARCHAR(15);
    DECLARE ReportHeader VARCHAR(255);
    
    -- Get current date and time
    SET @CurrentDateTime = NOW();
    
    -- Get manufacture details
    SELECT CompanyName, ContactNumber INTO CompanyName, ContactNumber 
    FROM Manufacture 
    WHERE ManufactureID = ManufactureID;
    
     -- Create report header
    SET ReportHeader = CONCAT('Report for ', CompanyName, ' (Contact: ', ContactNumber, ') - ', DATE_FORMAT(@CurrentDateTime, '%Y-%m-%d %H:%i:%s'));

    -- Print report header
    SELECT ReportHeader AS ReportHeader;
    
    -- Select expired products
    SELECT 
        FoodTypeID, 
        FoodTypeName, 
        ExpiryDate, 
        QuantityAmount, 
        QuantityUnit, 
        CategoryName
    FROM 
        vw_ExpiredFoodDetails
    WHERE 
        ManufactureID = ManufactureID;
END //

DELIMITER ;


--
CREATE TABLE AuditLog (
    LogID INT AUTO_INCREMENT PRIMARY KEY,
    LogType VARCHAR(50),
    PetTypeID INT,
    OldStockLevel INT,
    NewStockLevel INT,
    OperationTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);    

-- This trigger will be invoked after a new record is inserted into the PetTypes table. It will log the insertion into an audit table.
DELIMITER //

CREATE TRIGGER after_insert_pettype
AFTER INSERT ON PetTypes
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (LogType, PetTypeID, NewStockLevel)
    VALUES ('INSERT', NEW.PetTypeID, NEW.StockLevel);
END //

DELIMITER ;

-- This trigger will be invoked after the StockLevel of a pet type is updated in the PetTypes table. It will log the update into an audit table.

DELIMITER //

CREATE TRIGGER after_update_stocklevel
AFTER UPDATE ON PetTypes
FOR EACH ROW
BEGIN
    IF OLD.StockLevel <> NEW.StockLevel THEN
        INSERT INTO AuditLog (LogType, PetTypeID, OldStockLevel, NewStockLevel)
        VALUES ('UPDATE', NEW.PetTypeID, OLD.StockLevel, NEW.StockLevel);
    END IF;
END //

DELIMITER ;

CREATE INDEX idx_company_name ON Manufacture (CompanyName);
CREATE INDEX idx_contact_number ON Manufacture (ContactNumber);

CREATE INDEX idx_food_type_name ON FoodTypes (FoodName);
CREATE INDEX idx_expiry_date ON FoodTypes (ExpiryDate);

CREATE INDEX idx_category_name ON AnimalCategories (CategoryName);

CREATE INDEX idx_pet_type_name ON PetTypes (PetTypeName);
CREATE INDEX idx_stock_level ON PetTypes (StockLevel);

CREATE INDEX idx_quantity_amount ON FoodAllocations (QuantityAmount);
CREATE INDEX idx_quantity_unit ON FoodAllocations (QuantityUnit);




